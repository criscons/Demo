from django.contrib import admin
from api_rest.models import Report

admin.site.register(Report)
